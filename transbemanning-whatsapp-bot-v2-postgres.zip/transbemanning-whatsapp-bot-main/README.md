# TransBemanning WhatsApp-bot 2.0

Tidrapportering via WhatsApp Cloud API med permanent lagring i PostgreSQL.

## Kommandon

- `REG Hassan 3001` – registrerar eller uppdaterar föraren som skickar meddelandet.
- `IN` – checkar in.
- `UT` – checkar ut.
- `RAPPORT` – visar innevarande månads arbetstid.
- `RAPPORT 2026-07` – visar vald månad.
- `PDF 2026-07` – skickar PDF-rapport i WhatsApp.
- `EXCEL 2026-07` – skickar Excel-rapport i WhatsApp.
- `HJÄLP` – visar kommandona.

## Railway-variabler

Bottjänsten behöver följande variabler:

- `WHATSAPP_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_VERIFY_TOKEN`
- `WHATSAPP_API_VERSION` (valfri)
- `DATABASE_URL`

På Railway ska PostgreSQL-tjänstens `DATABASE_URL` göras tillgänglig i bottjänsten som en referensvariabel. Databastabellerna skapas automatiskt när boten startar.

## Start

```bash
npm install
npm start
```

Webhook-adress:

```text
https://DIN-RAILWAY-DOMÄN/webhook
```
