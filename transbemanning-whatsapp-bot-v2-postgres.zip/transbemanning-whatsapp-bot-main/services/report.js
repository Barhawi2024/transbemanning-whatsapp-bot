const moment = require('moment-timezone');

const TIMEZONE = 'Europe/Stockholm';

function getMonthRange(monthText) {
  let start;
  if (monthText && /^\d{4}-\d{2}$/.test(monthText)) {
    start = moment.tz(`${monthText}-01`, 'YYYY-MM-DD', TIMEZONE).startOf('month');
  } else {
    start = moment.tz(TIMEZONE).startOf('month');
  }
  return {
    start: start.clone().utc().toISOString(),
    end: start.clone().add(1, 'month').utc().toISOString(),
    label: start.format('YYYY-MM')
  };
}

function buildAttendanceReport({ activities = [], drivers = [], monthLabel }) {
  const driverMap = new Map(drivers.map((d) => [String(d.phone), d]));
  const bySender = new Map();

  for (const activity of activities) {
    if (!['check-in', 'check-out'].includes(activity.action)) continue;
    const sender = String(activity.sender);
    if (!bySender.has(sender)) bySender.set(sender, []);
    bySender.get(sender).push(activity);
  }

  const shifts = [];
  const summaries = [];

  for (const [sender, events] of bySender.entries()) {
    let openCheckIn = null;
    let totalMinutes = 0;
    const driver = driverMap.get(sender) || {
      name: events.find((e) => e.driver_name)?.driver_name || sender,
      phone: sender,
      vehicle_number: events.find((e) => e.vehicle_number)?.vehicle_number || ''
    };

    for (const event of events) {
      if (event.action === 'check-in') {
        openCheckIn = event;
      } else if (event.action === 'check-out' && openCheckIn) {
        const start = moment(openCheckIn.occurred_at);
        const end = moment(event.occurred_at);
        const minutes = Math.max(0, end.diff(start, 'minutes'));
        totalMinutes += minutes;
        shifts.push({
          name: driver.name,
          phone: sender,
          vehicleNumber: driver.vehicle_number || '',
          checkIn: start.tz(TIMEZONE).format('YYYY-MM-DD HH:mm'),
          checkOut: end.tz(TIMEZONE).format('YYYY-MM-DD HH:mm'),
          minutes,
          hoursText: formatMinutes(minutes)
        });
        openCheckIn = null;
      }
    }

    summaries.push({
      name: driver.name,
      phone: sender,
      vehicleNumber: driver.vehicle_number || '',
      totalMinutes,
      totalHoursText: formatMinutes(totalMinutes),
      openShift: Boolean(openCheckIn)
    });
  }

  summaries.sort((a, b) => a.name.localeCompare(b.name, 'sv'));
  shifts.sort((a, b) => a.checkIn.localeCompare(b.checkIn));

  return {
    monthLabel,
    driverCount: drivers.length,
    shiftCount: shifts.length,
    summaries,
    shifts,
    generatedAt: moment.tz(TIMEZONE).format('YYYY-MM-DD HH:mm')
  };
}

function formatMinutes(totalMinutes) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours} h ${String(minutes).padStart(2, '0')} min`;
}

function buildTextReport(report) {
  if (!report.summaries.length) {
    return `📊 Rapport ${report.monthLabel}\nIngen arbetstid registrerad.`;
  }

  const lines = [`📊 *Arbetstidsrapport ${report.monthLabel}*`];
  for (const row of report.summaries) {
    const vehicle = row.vehicleNumber ? ` • Bil ${row.vehicleNumber}` : '';
    const open = row.openShift ? ' • ⚠️ fortfarande IN' : '';
    lines.push(`• ${row.name}: ${row.totalHoursText}${vehicle}${open}`);
  }
  lines.push(`\nAntal avslutade pass: ${report.shiftCount}`);
  return lines.join('\n');
}

module.exports = {
  getMonthRange,
  buildAttendanceReport,
  buildTextReport,
  formatMinutes
};
