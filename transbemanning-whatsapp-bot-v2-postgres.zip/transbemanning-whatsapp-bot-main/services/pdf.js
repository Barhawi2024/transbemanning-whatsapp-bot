const PDFDocument = require('pdfkit');

async function generatePdfReport(report) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 45, size: 'A4' });
    const chunks = [];

    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    doc.fontSize(18).text('TransBemanning AB', { align: 'center' });
    doc.fontSize(14).text(`Arbetstidsrapport ${report.monthLabel}`, { align: 'center' });
    doc.moveDown();

    if (!report.summaries.length) {
      doc.fontSize(11).text('Ingen arbetstid registrerad.');
    } else {
      report.summaries.forEach((row) => {
        const vehicle = row.vehicleNumber ? ` | Bil: ${row.vehicleNumber}` : '';
        const open = row.openShift ? ' | ÖPPET PASS' : '';
        doc.fontSize(11).text(`${row.name} | ${row.totalHoursText}${vehicle}${open}`);
      });
    }

    doc.moveDown();
    doc.fontSize(9).text(`Avslutade pass: ${report.shiftCount}`);
    doc.text(`Skapad: ${report.generatedAt}`);
    doc.end();
  });
}

module.exports = { generatePdfReport };
