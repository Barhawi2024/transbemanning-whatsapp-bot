const ExcelJS = require('exceljs');

async function generateExcelReport(report) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'TransBemanning AB';

  const summary = workbook.addWorksheet('Sammanfattning');
  summary.columns = [
    { header: 'Förare', key: 'name', width: 25 },
    { header: 'Telefon', key: 'phone', width: 18 },
    { header: 'Bilnummer', key: 'vehicleNumber', width: 15 },
    { header: 'Totalt minuter', key: 'totalMinutes', width: 16 },
    { header: 'Total arbetstid', key: 'totalHoursText', width: 20 },
    { header: 'Öppet pass', key: 'openShift', width: 12 }
  ];
  summary.getRow(1).font = { bold: true };
  report.summaries.forEach((row) => summary.addRow({ ...row, openShift: row.openShift ? 'Ja' : 'Nej' }));

  const shifts = workbook.addWorksheet('Arbetspass');
  shifts.columns = [
    { header: 'Förare', key: 'name', width: 25 },
    { header: 'Telefon', key: 'phone', width: 18 },
    { header: 'Bilnummer', key: 'vehicleNumber', width: 15 },
    { header: 'IN', key: 'checkIn', width: 20 },
    { header: 'UT', key: 'checkOut', width: 20 },
    { header: 'Minuter', key: 'minutes', width: 12 },
    { header: 'Arbetstid', key: 'hoursText', width: 18 }
  ];
  shifts.getRow(1).font = { bold: true };
  report.shifts.forEach((row) => shifts.addRow(row));

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

module.exports = { generateExcelReport };
