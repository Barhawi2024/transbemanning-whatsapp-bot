const { Pool } = require('pg');

let pool;

function getPool() {
  if (pool) return pool;

  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error('DATABASE_URL saknas. Koppla Railway PostgreSQL till bottjänsten.');
  }

  const usesInternalRailwayHost = connectionString.includes('railway.internal');
  const ssl = process.env.PGSSLMODE === 'disable' || usesInternalRailwayHost
    ? false
    : { rejectUnauthorized: false };

  pool = new Pool({
    connectionString,
    ssl,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
  });

  pool.on('error', (error) => console.error('PostgreSQL pool error', error));
  return pool;
}

function normalizePhone(phone = '') {
  return String(phone).replace(/[^0-9]/g, '');
}

async function initDatabase() {
  const db = getPool();

  await db.query(`
    CREATE TABLE IF NOT EXISTS drivers (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      vehicle_number TEXT,
      active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS messages (
      id BIGSERIAL PRIMARY KEY,
      sender TEXT NOT NULL,
      type TEXT,
      body TEXT,
      whatsapp_message_id TEXT UNIQUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS activities (
      id BIGSERIAL PRIMARY KEY,
      sender TEXT NOT NULL,
      driver_id BIGINT REFERENCES drivers(id) ON DELETE SET NULL,
      action TEXT NOT NULL,
      body TEXT,
      occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE INDEX IF NOT EXISTS idx_activities_sender_time
      ON activities(sender, occurred_at);
    CREATE INDEX IF NOT EXISTS idx_activities_driver_time
      ON activities(driver_id, occurred_at);
  `);

  return true;
}

async function saveMessage(payload) {
  const sender = normalizePhone(payload.sender) || 'unknown';
  const result = await getPool().query(
    `INSERT INTO messages(sender, type, body, whatsapp_message_id)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (whatsapp_message_id) DO NOTHING
     RETURNING *`,
    [sender, payload.type || null, payload.body || null, payload.whatsappMessageId || null]
  );
  return result.rows[0] || null;
}

async function listMessages({ limit = 1000 } = {}) {
  const safeLimit = Math.min(Math.max(Number(limit) || 1000, 1), 5000);
  const result = await getPool().query(
    'SELECT * FROM messages ORDER BY created_at DESC LIMIT $1',
    [safeLimit]
  );
  return result.rows;
}

async function saveDriver({ name, phone, vehicleNumber }) {
  const normalizedPhone = normalizePhone(phone);
  if (!normalizedPhone) throw new Error('Telefonnummer saknas.');
  if (!String(name || '').trim()) throw new Error('Förarnamn saknas.');

  const result = await getPool().query(
    `INSERT INTO drivers(name, phone, vehicle_number)
     VALUES ($1, $2, $3)
     ON CONFLICT (phone) DO UPDATE SET
       name = EXCLUDED.name,
       vehicle_number = EXCLUDED.vehicle_number,
       active = TRUE,
       updated_at = NOW()
     RETURNING *`,
    [String(name).trim(), normalizedPhone, vehicleNumber ? String(vehicleNumber).trim() : null]
  );
  return result.rows[0];
}

async function getDriverByPhone(phone) {
  const result = await getPool().query(
    'SELECT * FROM drivers WHERE phone = $1 AND active = TRUE LIMIT 1',
    [normalizePhone(phone)]
  );
  return result.rows[0] || null;
}

async function listDrivers() {
  const result = await getPool().query(
    'SELECT * FROM drivers WHERE active = TRUE ORDER BY name ASC'
  );
  return result.rows;
}

async function saveActivity(activity) {
  const sender = normalizePhone(activity.sender) || 'unknown';
  let driverId = activity.driverId || null;
  if (!driverId) {
    const driver = await getDriverByPhone(sender);
    driverId = driver?.id || null;
  }

  const result = await getPool().query(
    `INSERT INTO activities(sender, driver_id, action, body, occurred_at)
     VALUES ($1, $2, $3, $4, COALESCE($5::timestamptz, NOW()))
     RETURNING *`,
    [sender, driverId, activity.action, activity.body || null, activity.occurredAt || null]
  );
  return result.rows[0];
}

async function getLastAttendanceActivity(sender) {
  const result = await getPool().query(
    `SELECT * FROM activities
     WHERE sender = $1 AND action IN ('check-in', 'check-out')
     ORDER BY occurred_at DESC, id DESC LIMIT 1`,
    [normalizePhone(sender)]
  );
  return result.rows[0] || null;
}

async function listActivities({ start, end, sender } = {}) {
  const conditions = [];
  const values = [];
  if (start) {
    values.push(start);
    conditions.push(`a.occurred_at >= $${values.length}`);
  }
  if (end) {
    values.push(end);
    conditions.push(`a.occurred_at < $${values.length}`);
  }
  if (sender) {
    values.push(normalizePhone(sender));
    conditions.push(`a.sender = $${values.length}`);
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const result = await getPool().query(
    `SELECT a.*, d.name AS driver_name, d.vehicle_number
     FROM activities a
     LEFT JOIN drivers d ON d.id = a.driver_id
     ${where}
     ORDER BY a.occurred_at ASC, a.id ASC`,
    values
  );
  return result.rows;
}

module.exports = {
  initDatabase,
  saveMessage,
  listMessages,
  saveDriver,
  getDriverByPhone,
  listDrivers,
  saveActivity,
  getLastAttendanceActivity,
  listActivities,
  normalizePhone
};
