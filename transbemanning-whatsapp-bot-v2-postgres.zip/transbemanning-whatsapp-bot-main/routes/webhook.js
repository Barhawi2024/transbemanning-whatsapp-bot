const express = require('express');
const axios = require('axios');
const FormData = require('form-data');
const {
  saveMessage,
  listDrivers,
  saveActivity,
  getDriverByPhone,
  getLastAttendanceActivity,
  listActivities
} = require('../database');
const { registerDriver } = require('../services/driver');
const {
  getMonthRange,
  buildAttendanceReport,
  buildTextReport
} = require('../services/report');
const { generatePdfReport } = require('../services/pdf');
const { generateExcelReport } = require('../services/excel');
const { distanceBetweenPoints } = require('../services/gps');

const router = express.Router();
const TIMEZONE = 'Europe/Stockholm';

function graphBaseUrl() {
  const apiVersion = process.env.WHATSAPP_API_VERSION || 'v20.0';
  return `https://graph.facebook.com/${apiVersion}`;
}

function getWhatsAppConfig() {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneNumberId) {
    throw new Error('WHATSAPP_TOKEN eller WHATSAPP_PHONE_NUMBER_ID saknas.');
  }
  return { token, phoneNumberId };
}

async function sendWhatsAppText(to, body) {
  if (!body) return null;
  const { token, phoneNumberId } = getWhatsAppConfig();
  return axios.post(
    `${graphBaseUrl()}/${phoneNumberId}/messages`,
    {
      messaging_product: 'whatsapp',
      to,
      type: 'text',
      text: { body }
    },
    { headers: { Authorization: `Bearer ${token}` } }
  );
}

async function uploadWhatsAppMedia(buffer, filename, mimeType) {
  const { token, phoneNumberId } = getWhatsAppConfig();
  const form = new FormData();
  form.append('messaging_product', 'whatsapp');
  form.append('file', buffer, { filename, contentType: mimeType });

  const response = await axios.post(
    `${graphBaseUrl()}/${phoneNumberId}/media`,
    form,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        ...form.getHeaders()
      },
      maxBodyLength: Infinity
    }
  );
  return response.data.id;
}

async function sendWhatsAppDocument(to, buffer, filename, mimeType, caption) {
  const { token, phoneNumberId } = getWhatsAppConfig();
  const mediaId = await uploadWhatsAppMedia(buffer, filename, mimeType);

  return axios.post(
    `${graphBaseUrl()}/${phoneNumberId}/messages`,
    {
      messaging_product: 'whatsapp',
      to,
      type: 'document',
      document: { id: mediaId, filename, caption }
    },
    { headers: { Authorization: `Bearer ${token}` } }
  );
}

function swedishDateTime(date = new Date()) {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

function extractMonth(text) {
  return text.match(/\b(20\d{2}-(?:0[1-9]|1[0-2]))\b/)?.[1];
}

async function getReport(monthText) {
  const range = getMonthRange(monthText);
  const [activities, drivers] = await Promise.all([
    listActivities({ start: range.start, end: range.end }),
    listDrivers()
  ]);
  return buildAttendanceReport({ activities, drivers, monthLabel: range.label });
}

async function ensureDriver(sender, contact) {
  let driver = await getDriverByPhone(sender);
  if (!driver) {
    const profileName = contact?.profile?.name?.trim() || `Förare ${sender.slice(-4)}`;
    driver = await registerDriver({ name: profileName, phone: sender, vehicleNumber: null });
  }
  return driver;
}

async function handleIncomingMessage(message, contact) {
  const text = message.text?.body || '';
  const normalized = text.trim().toLowerCase();
  const sender = contact?.wa_id || message.from || 'unknown';

  const savedMessage = await saveMessage({
    sender,
    type: message.type,
    body: text,
    whatsappMessageId: message.id
  });

  // Meta kan ibland skicka samma webhook igen. Svara inte två gånger.
  if (message.id && !savedMessage) return null;

  if (!text) return { text: 'Skicka ett textkommando. Skriv HJÄLP för att se kommandon.' };

  if (normalized === 'hjälp' || normalized === 'help') {
    return {
      text:
        '🤖 *TransBemanning tidrapport*\n\n' +
        'REG Namn Bilnummer – registrera/uppdatera förare\n' +
        'IN – checka in\n' +
        'UT – checka ut\n' +
        'RAPPORT – månadens timmar\n' +
        'RAPPORT 2026-07 – vald månad\n' +
        'PDF 2026-07 – PDF-rapport\n' +
        'EXCEL 2026-07 – Excel-rapport'
    };
  }

  if (normalized === 'in') {
    const driver = await ensureDriver(sender, contact);
    const last = await getLastAttendanceActivity(sender);
    if (last?.action === 'check-in') {
      return { text: `⚠️ ${driver.name}, du är redan incheckad sedan ${swedishDateTime(last.occurred_at)}.` };
    }

    await saveActivity({ sender, driverId: driver.id, action: 'check-in', body: text });
    return { text: `✅ Incheckning registrerad för ${driver.name}.\nTid: ${swedishDateTime()}\nHa en bra arbetsdag!` };
  }

  if (normalized === 'ut') {
    const driver = await ensureDriver(sender, contact);
    const last = await getLastAttendanceActivity(sender);
    if (!last || last.action !== 'check-in') {
      return { text: `⚠️ ${driver.name}, ingen aktiv incheckning hittades. Skicka IN först.` };
    }

    await saveActivity({ sender, driverId: driver.id, action: 'check-out', body: text });
    return { text: `✅ Utcheckning registrerad för ${driver.name}.\nTid: ${swedishDateTime()}` };
  }

  if (normalized.startsWith('reg ') || normalized.startsWith('driver ')) {
    const parts = text.trim().split(/\s+/);
    parts.shift();
    if (!parts.length) {
      return { text: 'Skriv exempelvis: REG Hassan 3001' };
    }

    const vehicleNumber = parts.length > 1 ? parts.pop() : null;
    const name = parts.join(' ').trim();
    if (!name) return { text: 'Skriv exempelvis: REG Hassan 3001' };

    const driver = await registerDriver({ name, phone: sender, vehicleNumber });
    await saveActivity({ sender, driverId: driver.id, action: 'register-driver', body: text });
    return {
      text: `✅ Förare registrerad\nNamn: ${driver.name}\nTelefon: ${driver.phone}\nBil: ${driver.vehicle_number || 'inte angiven'}`
    };
  }

  if (normalized.startsWith('rapport') || normalized.startsWith('report')) {
    const report = await getReport(extractMonth(text));
    await saveActivity({ sender, action: 'generate-report', body: text });
    return { text: buildTextReport(report) };
  }

  if (normalized.startsWith('pdf')) {
    const report = await getReport(extractMonth(text));
    const buffer = await generatePdfReport(report);
    await saveActivity({ sender, action: 'generate-pdf', body: text });
    return {
      document: {
        buffer,
        filename: `TransBemanning-${report.monthLabel}.pdf`,
        mimeType: 'application/pdf',
        caption: `Arbetstidsrapport ${report.monthLabel}`
      }
    };
  }

  if (normalized.startsWith('excel')) {
    const report = await getReport(extractMonth(text));
    const buffer = await generateExcelReport(report);
    await saveActivity({ sender, action: 'generate-excel', body: text });
    return {
      document: {
        buffer,
        filename: `TransBemanning-${report.monthLabel}.xlsx`,
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        caption: `Arbetstidsrapport ${report.monthLabel}`
      }
    };
  }

  if (normalized.startsWith('gps')) {
    const match = text.match(/(-?\d+(?:\.\d+)?)[,\s]+(-?\d+(?:\.\d+)?)/);
    if (match) {
      const lat = Number(match[1]);
      const lon = Number(match[2]);
      const distance = distanceBetweenPoints({ lat, lon }, { lat: 59.3293, lon: 18.0686 });
      await saveActivity({ sender, action: 'gps-check', body: text });
      return { text: `Avstånd till Stockholm: ${distance.toFixed(2)} km` };
    }
    return { text: 'Skicka GPS-koordinater så här: GPS 59.3293, 18.0686' };
  }

  return { text: 'Jag förstod inte kommandot. Skriv HJÄLP för att se kommandon.' };
}

router.get('/', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

router.post('/', async (req, res) => {
  // Bekräfta snabbt till Meta. Bearbeta sedan meddelandet.
  res.sendStatus(200);

  try {
    for (const entry of req.body.entry || []) {
      for (const change of entry.changes || []) {
        const value = change.value || {};
        const contacts = value.contacts || [];

        for (const message of value.messages || []) {
          const contact = contacts.find((item) => item.wa_id === message.from) || contacts[0] || {};
          const reply = await handleIncomingMessage(message, contact);
          if (!reply || !message.from) continue;

          if (reply.text) await sendWhatsAppText(message.from, reply.text);
          if (reply.document) {
            await sendWhatsAppDocument(
              message.from,
              reply.document.buffer,
              reply.document.filename,
              reply.document.mimeType,
              reply.document.caption
            );
          }
        }
      }
    }
  } catch (error) {
    const details = error.response?.data || error.message;
    console.error('Webhook processing error', details);
  }
});

module.exports = router;
