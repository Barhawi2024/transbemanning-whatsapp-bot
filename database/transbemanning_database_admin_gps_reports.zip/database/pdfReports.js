const PDFDocument = require('pdfkit');
const {
  getDriverMonthlyReport,
  getCompanyMonthlyReport,
  minutesToHoursText
} = require('./reports');

function monthName(month) {
  const names = [
    'Januari', 'Februari', 'Mars', 'April', 'Maj', 'Juni',
    'Juli', 'Augusti', 'September', 'Oktober', 'November', 'December'
  ];

  return names[Number(month) - 1] || String(month);
}

function createPdfBuffer(buildDocument) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margin: 40,
      info: {
        Title: 'TransBemanning rapport',
        Author: 'TransBemanning AB'
      }
    });

    const chunks = [];

    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    buildDocument(doc);
    doc.end();
  });
}

async function createDriverMonthlyPdf(driverId, year, month) {
  const report = await getDriverMonthlyReport(driverId, year, month);

  return createPdfBuffer((doc) => {
    doc.fontSize(18).text('TransBemanning AB');
    doc.moveDown(0.3);
    doc.fontSize(15).text(
      `Månadsrapport – ${monthName(month)} ${year}`
    );
    doc.moveDown();

    doc.fontSize(11);
    doc.text(`Förar-ID: ${driverId}`);
    doc.text(`Namn: ${report.driver?.name || '-'}`);
    doc.text(`Telefon: ${report.driver?.phone || '-'}`);
    doc.text(`Bil: ${report.driver?.vehicle_number || '-'}`);
    doc.moveDown();

    doc.fontSize(12).text(`Totalt: ${report.totals.totalText}`);
    doc.text(`Avslutade pass: ${report.totals.closedSessions}`);
    doc.text(`Öppna pass: ${report.totals.openSessions}`);
    doc.moveDown();

    doc.fontSize(10).text('Arbetspass', { underline: true });
    doc.moveDown(0.4);

    for (const session of report.sessions) {
      const inTime = new Date(session.check_in_at).toLocaleString('sv-SE');
      const outTime = session.check_out_at
        ? new Date(session.check_out_at).toLocaleString('sv-SE')
        : 'Öppet pass';

      doc.text(
        `${inTime} → ${outTime} | Rast: ${session.break_minutes || 0} min | ` +
        `Arbetstid: ${minutesToHoursText(session.worked_minutes || 0)}`
      );

      if (doc.y > 740) {
        doc.addPage();
      }
    }
  });
}

async function createCompanyMonthlyPdf(year, month) {
  const report = await getCompanyMonthlyReport(year, month);

  return createPdfBuffer((doc) => {
    doc.fontSize(18).text('TransBemanning AB');
    doc.moveDown(0.3);
    doc.fontSize(15).text(
      `Företagets månadsrapport – ${monthName(month)} ${year}`
    );
    doc.moveDown();

    doc.fontSize(12).text(`Företag totalt: ${report.companyTotalText}`);
    doc.moveDown();

    doc.fontSize(10);

    for (const driver of report.drivers) {
      doc.text(
        `${driver.driver_id} | ${driver.name || '-'} | ` +
        `${driver.totalText} | Pass: ${driver.closed_sessions}`
      );

      if (doc.y > 740) {
        doc.addPage();
      }
    }
  });
}

module.exports = {
  createDriverMonthlyPdf,
  createCompanyMonthlyPdf
};
