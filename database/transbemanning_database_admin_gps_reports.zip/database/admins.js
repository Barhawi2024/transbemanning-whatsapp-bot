const { query } = require('./connection');

function normalizePhone(phone = '') {
  return String(phone).replace(/\D/g, '');
}

async function addAdmin(phone, name = null) {
  const normalized = normalizePhone(phone);

  const result = await query(
    `
      INSERT INTO admins (phone, name, is_active)
      VALUES ($1, $2, TRUE)
      ON CONFLICT (phone)
      DO UPDATE SET
        name = COALESCE(EXCLUDED.name, admins.name),
        is_active = TRUE,
        updated_at = NOW()
      RETURNING *
    `,
    [normalized, name]
  );

  return result.rows[0];
}

async function removeAdmin(phone) {
  const normalized = normalizePhone(phone);

  const result = await query(
    `
      UPDATE admins
      SET is_active = FALSE, updated_at = NOW()
      WHERE phone = $1
      RETURNING *
    `,
    [normalized]
  );

  return result.rows[0] || null;
}

async function isAdmin(phone) {
  const normalized = normalizePhone(phone);
  const envAdmin = normalizePhone(process.env.ADMIN_PHONE || '');

  if (envAdmin && normalized === envAdmin) {
    return true;
  }

  const result = await query(
    `
      SELECT 1
      FROM admins
      WHERE phone = $1 AND is_active = TRUE
      LIMIT 1
    `,
    [normalized]
  );

  return result.rowCount > 0;
}

async function listAdmins() {
  const result = await query(
    `
      SELECT *
      FROM admins
      WHERE is_active = TRUE
      ORDER BY name NULLS LAST, phone
    `
  );

  return result.rows;
}

module.exports = {
  normalizePhone,
  addAdmin,
  removeAdmin,
  isAdmin,
  listAdmins
};
