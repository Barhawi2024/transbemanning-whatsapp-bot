TRANSBEMANNING DATABASE – NÄSTA FILER

Lägg dessa filer direkt i mappen database/:
- commands.js
- admins.js
- gps.js
- reports.js
- pdfReports.js

VIKTIGT:
1. Öppna database/setup-extra.js i paketet.
2. Kopiera SQL-koden.
3. Klistra in den INUTI funktionen setupDatabase() i din befintliga database/setup.js,
   precis före:
   console.log('✅ Database tables ready');

4. Ersätt innehållet i din database/index.js med innehållet i:
   database/index-full.js

5. Se till att package.json innehåller:
   "pg"
   "pdfkit"

Detta paket skapar databaskoden för:
- Alla admin-kommandon
- Loggning av REG, IN, UT, HOURS, REPORT och framtida kommandon
- GPS-positioner och GPS-historik
- Dagsrapport
- Förarens månadsrapport
- Företagets månadsrapport
- Juli-rapport eller valfri månad
- PDF-rapport för en förare
- PDF-rapport för hela företaget

OBS:
Filerna kopplar databasen, men själva WhatsApp-kommandona måste därefter anslutas
i routes/webhook.js. Det gör vi i nästa steg.
